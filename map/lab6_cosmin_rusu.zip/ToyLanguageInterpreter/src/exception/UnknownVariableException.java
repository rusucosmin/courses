package exception;

/**
 * Created by cosmin on 02/11/16.
 */
public class UnknownVariableException extends Exception {
    public UnknownVariableException(String s) {
        super(s);
    }
}
