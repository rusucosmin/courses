package exception;

/**
 * Created by cosmin on 10/24/16.
 */
public class KeyNotExistException extends Exception {
    public KeyNotExistException() { super(); }
    public KeyNotExistException(String s) { super(s); }
}
