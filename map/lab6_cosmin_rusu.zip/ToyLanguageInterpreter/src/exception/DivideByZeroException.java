package exception;

/**
 * Created by cosmin on 02/11/16.
 */
public class DivideByZeroException extends Exception {
    public DivideByZeroException(String s) {
        super(s);
    }
}
