from models.poligon import Poligon

class Tester:
    def __init__(self):
        pass

    def testPoligon(self):
        p = Poligon(4, [[-2, -2], [2, -2], [2, 2], [-2, 2]])
        assert(p.getArea() - 16.00 < 0.00001)
        q = Poligon(4, [[-2, -2], [2, -2], [2, 2], [-2, 2]])
        assert(p == q)
        assert(p <= q)
        assert(p >= q)