## Week 5 solutions.

Use iPython notebook to preprocess the initial climate data.

For the sake of interpretability, during the preprocessing we compute the average temperature over each year.
