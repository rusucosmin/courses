# Data Visualization TA. Week 8 solutions

## Assignment
Create a choropleth map of Switzerland using D3JS. Color each canton according to its population density. Display Instagram posts' locations on the map. Details and datasets are in [Google Docs](https://docs.google.com/document/d/1FHFM87AvS_rq2gi7rqV7rIsM4hoopZcr8HDlngrj9tI/edit?usp=sharing).

## Solution
[Open](http://blog.miz.space/dataviz/choropleth-switzerland-instagram/) the solution in your browser.

![alt text](https://raw.githubusercontent.com/mizvol/dataVizTA_week8/master/viz8.jpg)