#!/bin/bash

A=""

if [ "$A" = "" ]; then
    echo asdf
fi
