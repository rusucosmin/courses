#include "lecture13_demo.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	Lecture13_demo w;
	w.show();
	return a.exec();
}
