#include "lecture9_demo_hello_world.h"

Lecture9_demo_Hello_world::Lecture9_demo_Hello_world(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

Lecture9_demo_Hello_world::~Lecture9_demo_Hello_world()
{

}
