#include "lecture9_demo_qt_designer.h"

Lecture9_demo_Qt_designer::Lecture9_demo_Qt_designer(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

Lecture9_demo_Qt_designer::~Lecture9_demo_Qt_designer()
{

}
