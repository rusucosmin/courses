#include "lecture9_demo_widgets.h"

Lecture9_demo_widgets::Lecture9_demo_widgets(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

Lecture9_demo_widgets::~Lecture9_demo_widgets()
{

}
