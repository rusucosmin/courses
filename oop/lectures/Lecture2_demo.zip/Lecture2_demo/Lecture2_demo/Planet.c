#include "Planet.h"

Planet createPlanet(char chevrons[], char name[], char solarSystem[], double distanceToEarth)
{
	Planet p;
	strcpy(p.chevrons, chevrons);
	strcpy(p.name, name);
	strcpy(p.solarSystem, solarSystem);
	p.distanceToEarth = distanceToEarth;

	return p;
}