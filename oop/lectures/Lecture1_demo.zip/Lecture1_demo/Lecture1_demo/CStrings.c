//#include <stdio.h>
//#include <string.h>
//
//int main() 
//{
//	char surname[50];
//	char firstName[50]; 
//	char name[100];
//
//	strcpy(surname, "Smith");
//	printf("surname = '%s' length = %d\n", surname, strlen(surname));
//	
//	strcpy(firstName, "John"); // buffer overflow (this will corrupt the stack), if the allocated space is not enough
//	printf("first name = '%s' length = %d\n", firstName, strlen(firstName));
//	
//	strcpy(name, firstName);
//	strcat(name, " ");
//	strcat(name, surname);
//
//	printf("name = '%s' length = %d\n", name, strlen(name));
//
//	return 0;
//}