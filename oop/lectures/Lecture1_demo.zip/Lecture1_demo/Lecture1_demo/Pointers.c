//#include <stdio.h>
//#include <windows.h>
//
//int main() 
//{
//	system("color f4");
//
//	int a = 7;
//	printf("Value of a: %d, address of a: %p \n", a, &a);
//
//	//assign the address of a to pa
//	int *pa;
//	pa = &a;
//	printf("Value of pa: %p, address of pa: %p \n", pa, &pa);
//
//	//a and pa refers to the same memory location
//	a = 10;
//	printf("Value of a: %d, dereference of pa: %d \n", a, *pa);
//	return 0;
//}