#!/bin/bash

R=`./p 12 15 | sed 's/\..*//'`

if test $R -ge 5; then
    echo marisor
fi

if [ $R -ge 6 ] || [ ! $R -gt 4 ]; then
    echo tot asa
fi

A=1
B=1
while [ `./p $A $B | sed 's/\..*//'` -lt 3 ]; do
    A=`expr $A + 1`
    B=`expr $B + 1`
    echo $A $B
done



