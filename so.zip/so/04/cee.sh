#!/bin/bash

if echo $1 | grep -q '^[A-Za-z]$' ; then
    echo Litera
elif echo $1 | grep -q '^[0-9]$' ; then
    echo Cifra
else
    echo Altceva
fi

case $1 in
    [a-zA-Z] ) echo Litera ;;
    [0-9] ) echo Cifra ;;
    * ) echo Altceva ;;
esac
