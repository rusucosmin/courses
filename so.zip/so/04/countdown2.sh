#!/bin/bash

N=$1
if ! echo $1 | grep -q '^[0-9]\+$'; then 
    echo "ERROR: Vrem numere!" >&2
    exit 1
fi

if [ $1 -eq 0 ]; then
    echo "START!"
gelse
    echo $N
    sleep 2
    ./countdown2.sh `expr $N - 1`
fi
