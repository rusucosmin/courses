#!/bin/bash

echo =======================================
for V in aa b123 c d6yu e f g h; do
    echo $V
done

echo =======================================
for A in $*; do
    echo $A
done

echo =======================================
for F in *; do
    echo $F
done
for F in ./*; do
    echo $F
done
for F in ../03/[a-z]*; do
    echo $F
done
