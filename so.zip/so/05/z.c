#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    int i, fiu;
    for(i=0; i<10; i++) {
        fiu = fork();
        if(fiu == 0) {
            exit(0);
        }
    }
    sleep(10);
    return 0;
}
