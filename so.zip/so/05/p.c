#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    int i, fiu;
    for(i=0; i<100; i++) {
        fiu = fork();
        if(fiu == 0) {
            printf("%d.%d\n", getppid(), getpid());
            exit(0);
        }
        printf("Am creat %d\n", fiu);

    }
    return 0;
}
