#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    int i, fiu;
    for(i=0; i<20; i++) {
        fiu = fork();
        if(fiu == 0) {
            printf("\n###########################################\n");
            execl("/bin/ps", "/bin/ps", "-f", NULL);
            exit(0);
        }
    }
    for(i=0; i<20; i++) {
        wait(0);
    }
    return 0;
}
