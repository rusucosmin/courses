#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    int i, fiu;
    for(i=0; i<20; i++) {
        fiu = fork();
        if(fiu == 0) {
            printf("%d.%d %d\n", getppid(), getpid(), i);
            exit(0);
        }
    }
    for(i=0; i<20; i++) {
        wait(0);
    }
    return 0;
}
