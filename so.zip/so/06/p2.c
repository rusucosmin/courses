#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int sum = 0;

int main() {
    int i, fiu;
    for(i=0; i<20; i++) {
        fiu = fork();
        if(fiu == 0) {
            sum += 1;
            printf("%d\n", sum);
            exit(0);
        }
    }
    for(i=0; i<20; i++) {
        wait(0);
    }
    printf("%d\n", sum);
    return 0;
}
