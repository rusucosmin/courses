#include <iostream>
#include <vector>
#include <deque>
#include <algorithm>
#include <iterator>

int main()
{
	system("color f4");

	// output iterator
	std::vector<int> myvector;
	for (int i = 1; i < 10; i++) 
		myvector.push_back(i * 10);

	std::ostream_iterator<int> out_it(std::cout, ", ");
	std::copy(myvector.begin(), myvector.end(), out_it);
	std::cout << std::endl;

	std::vector<int> v{ 1, 2, 3, 4, 5, 6 };
	std::vector<int> odds;
	std::deque<int> evens;

	// back inserter
	copy_if(v.begin(), v.end(), back_inserter(odds), [](int x) { return x % 2 == 1; });
	for_each(odds.begin(), odds.end(), [](int x) { std::cout << x << " "; });	// 1 3 5
	std::cout << std::endl;
	
	// front inserter
	std::front_insert_iterator<std::deque<int>> evensIterator(evens);
	copy_if(v.begin(), v.end(), evensIterator, [](int x) { return x % 2 == 0; });	
	for_each(evens.begin(), evens.end(), [](int x) { std::cout << x << " "; });	// 6 4 2
	std::cout << std::endl;
	
	system("pause");
}
