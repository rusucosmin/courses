See instructions at:

http://dotty.epfl.ch/docs/usage/ide-support.html

In particular, after installing Visual Studio Code, run "sbt launchIDE".
